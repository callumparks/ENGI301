This model is courtesy of Steve Smitka.

![PocketBeagle 3D model](PocketBeagle_3dmodel.png "Render of 3D model")

