# Fritzing model of PocketBeagle

[Fritzing](http://fritzing.org/) is an easy way to document your projects and even design PCBs.

This is now [upstream](https://github.com/fritzing/fritzing-parts/blob/master/core/PocketBeagle.fzp), so use the upstream version.

![PocketBeagle breadboard view](breadboard/PocketBeagle_breadboard.svg "Breadboard style view in Fritzing")
